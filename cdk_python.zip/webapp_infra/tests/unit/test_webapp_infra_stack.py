import aws_cdk as core
import aws_cdk.assertions as assertions

from webapp_infra.webapp_infra_stack import WebappInfraStack

# example tests. To run these tests, uncomment this file along with the example
# resource in webapp_infra/webapp_infra_stack.py
def test_sqs_queue_created():
    app = core.App()
    stack = WebappInfraStack(app, "webapp-infra")
    template = assertions.Template.from_stack(stack)

#     template.has_resource_properties("AWS::SQS::Queue", {
#         "VisibilityTimeout": 300
#     })

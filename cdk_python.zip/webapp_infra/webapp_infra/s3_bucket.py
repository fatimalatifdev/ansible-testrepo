from aws_cdk import (
    Stack,
    CfnOutput,
    aws_s3 as s3,
)
from constructs import Construct

class S3Stack(Stack):

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # Create a private S3 bucket using L1 (CfnBucket)
        bucket = s3.CfnBucket(
            self,
            id="frontend_bucket",
            bucket_name="webappstatic-bucket",
            public_access_block_configuration=s3.CfnBucket.PublicAccessBlockConfigurationProperty(
                block_public_acls=True,
                block_public_policy=True,
                ignore_public_acls=True,
                restrict_public_buckets=True
            ),
            access_control="Private",  # Optional: ensures bucket ACL is set to private
            # website_configuration=s3.CfnBucket.WebsiteConfigurationProperty(
            #     index_document="index.html",
            #     error_document="error.html"  # optional
            # )
        )

        # Output the bucket name
        CfnOutput(
            self,
            "BucketNameOutput",
            value=bucket.ref,  # `ref` returns the bucket name for CfnBucket
            export_name="frontendbucket"
        )
        # CfnOutput(
        #     self,
        #     "BucketWebsiteURL",
        #     value=bucket.attr_website_url,
        #     export_name="StaticWebsiteURL"
        # )

from aws_cdk import (
    Stack,
    aws_ec2 as ec2,
    aws_elasticloadbalancingv2 as elbv2,
    CfnOutput,
)
from constructs import Construct

class AlbStack(Stack):

    def __init__(self, scope: Construct, id: str, vpc_id: str, public_subnet_ids: list[str], **kwargs) -> None:
        super().__init__(scope, id, **kwargs)

        # Create security group for ALB allowing only HTTP (80) and HTTPS (443)
        alb_sg = ec2.CfnSecurityGroup(
            self,
            "ALBSecurityGroup",
            group_description="Allow HTTP and HTTPS inbound to ALB",
            vpc_id=vpc_id,
            security_group_ingress=[
                ec2.CfnSecurityGroup.IngressProperty(
                    ip_protocol="tcp",
                    from_port=80,
                    to_port=80,
                    cidr_ip="0.0.0.0/0"
                ),
                ec2.CfnSecurityGroup.IngressProperty(
                    ip_protocol="tcp",
                    from_port=443,
                    to_port=443,
                    cidr_ip="0.0.0.0/0"
                ),
            ],
            security_group_egress=[
                ec2.CfnSecurityGroup.EgressProperty(
                    ip_protocol="-1",
                    from_port=0,
                    to_port=0,
                    cidr_ip="0.0.0.0/0"
                ),
            ]
        )

        # Create the Application Load Balancer
        alb = elbv2.CfnLoadBalancer(
            self,
            "ApplicationLoadBalancer",
            name="AppALB",
            subnets=public_subnet_ids,
            security_groups=[alb_sg.attr_group_id],
            scheme="internet-facing",  # ALB is public facing
            type="application",
            ip_address_type="ipv4",
        )

        # Create a target group (assuming ECS instances IP mode, target type IP)
        target_group = elbv2.CfnTargetGroup(
            self,
            "TargetGroup",
            name="albTargetGroup",
            port=80,
            protocol="HTTP",
            vpc_id=vpc_id,
            target_type="instance",
            health_check_enabled=True,
            health_check_path="/",
            matcher=elbv2.CfnTargetGroup.MatcherProperty(
                http_code="200"
            )
        )

        # Create an ALB listener on port 80 forwarding to target group
        listener = elbv2.CfnListener(
            self,
            "Listener",
            load_balancer_arn=alb.ref,
            port=80,
            protocol="HTTP",
            default_actions=[{
                "type": "forward",
                "targetGroupArn": target_group.ref
            }]
        )

        # Output ALB DNS Name
        # CfnOutput(
        #     self,
        #     "LoadBalancerDNS",
        #     value=alb.attr_dns_name,
        #     export_name="AppLoadBalancerDNS"
        # )
        CfnOutput(self, "AlbSecurityGroupId", value=alb_sg.ref)
        CfnOutput(self, "AlbDnsName", value=alb.attr_dns_name)
        CfnOutput(self, "TargetGroupArn", value=target_group.ref)
       
        self.alb_sg = alb_sg.ref
        self.tg_arn= target_group.ref
        
import base64
from aws_cdk import (
    Stack,
    aws_ec2 as ec2,
    aws_ecs as ecs,
    aws_autoscaling as autoscaling,
    aws_iam as iam,
)
from constructs import Construct


class EcsStack(Stack):
    def __init__(
        self,
        scope: Construct,
        id: str,
        vpc_id: str,
        private_subnet_ids: list[str],
        alb_sg_id: str,
        target_group_arn: str,
        **kwargs
    ):
        super().__init__(scope, id, **kwargs)

        # Security Group for ECS instances
        ecs_sg = ec2.CfnSecurityGroup(
            self,
            "EcsInstanceSG",
            group_description="Allow traffic from ALB",
            vpc_id=vpc_id,
            security_group_ingress=[
                ec2.CfnSecurityGroup.IngressProperty(
                    ip_protocol="tcp",
                    from_port=80,
                    to_port=80,
                    cidr_ip="0.0.0.0/0"
                ),
            ],
            security_group_egress=[
                ec2.CfnSecurityGroup.EgressProperty(
                    ip_protocol="-1",
                    from_port=0,
                    to_port=0,
                    cidr_ip="0.0.0.0/0"
                ),
            ]
        )

        # IAM Role for EC2 instances
        instance_role = iam.Role(
            self, "EcsInstanceRole",
            assumed_by=iam.ServicePrincipal("ec2.amazonaws.com"),
            managed_policies=[
                iam.ManagedPolicy.from_aws_managed_policy_name("service-role/AmazonEC2ContainerServiceforEC2Role"),
                iam.ManagedPolicy.from_aws_managed_policy_name("CloudWatchAgentServerPolicy"),
                iam.ManagedPolicy.from_aws_managed_policy_name("AmazonS3ReadOnlyAccess"),
            ]
        )

        # IAM Instance Profile
        instance_profile = iam.CfnInstanceProfile(
            self, "EcsInstanceProfile",
            roles=[instance_role.role_name]
        )

        # ECS Cluster
        cluster = ecs.CfnCluster(self, "EcsCluster", cluster_name="EcsCluster")

        # User data (must be base64 encoded for CfnLaunchTemplate)
        user_data_script = "#!/bin/bash\necho ECS_CLUSTER=EcsCluster >> /etc/ecs/ecs.config"
        encoded_user_data = base64.b64encode(user_data_script.encode("utf-8")).decode("utf-8")

        # ECS-optimized AMI from SSM Parameter Store
        ecs_ami = ec2.MachineImage.from_ssm_parameter(
            parameter_name="/aws/service/ecs/optimized-ami/amazon-linux-2/recommended/image_id"
        ).get_image(self).image_id

        # Launch Template using ECS-optimized AMI
        launch_template = ec2.CfnLaunchTemplate(
            self, "EcsLaunchTemplate",
            launch_template_data=ec2.CfnLaunchTemplate.LaunchTemplateDataProperty(
                image_id=ecs_ami,
                instance_type="t3.micro",
                security_group_ids=[ecs_sg.attr_group_id],
                iam_instance_profile=ec2.CfnLaunchTemplate.IamInstanceProfileProperty(
                    name=instance_profile.ref
                ),
                user_data=encoded_user_data
            )
        )

        # Auto Scaling Group
        asg = autoscaling.CfnAutoScalingGroup(
            self, "EcsAsg",
            min_size="2",
            max_size="4",
            desired_capacity="2",
            vpc_zone_identifier=private_subnet_ids,
            launch_template=autoscaling.CfnAutoScalingGroup.LaunchTemplateSpecificationProperty(
                launch_template_id=launch_template.ref,
                version=launch_template.attr_latest_version_number
            )
        )

        # ECS Task Definition
        task_def = ecs.CfnTaskDefinition(
            self, "EcsTaskDef",
            family="MyTaskDef",
            network_mode="bridge",
            requires_compatibilities=["EC2"],
            cpu="256",
            memory="512",
            container_definitions=[{
                "name": "web",
                "image": "nginx",
                "portMappings": [{
                    "containerPort": 80,
                    "hostPort": 80,
                    "protocol": "tcp"
                }]
            }]
        )

        # ECS Service
        service = ecs.CfnService(
            self, "EcsService",
            cluster=cluster.ref,
            desired_count=2,
            launch_type="EC2",
            task_definition=task_def.ref,
            load_balancers=[ecs.CfnService.LoadBalancerProperty(
                container_name="web",
                container_port=80,
                target_group_arn=target_group_arn
            )],
            placement_strategies=[ecs.CfnService.PlacementStrategyProperty(
                type="spread",
                field="attribute:ecs.availability-zone"
            )],
        )

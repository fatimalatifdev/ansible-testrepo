from aws_cdk import (
    Stack,
    CfnOutput,
    aws_ec2 as ec2,
)
from constructs import Construct


class VpcStack(Stack):

    def __init__(self, scope: Construct, id: str, **kwargs) -> None:
        super().__init__(scope, id, **kwargs)

        # 1. Create the VPC
        vpc = ec2.CfnVPC(
            self, "Vpcapp",
            cidr_block="10.0.0.0/16",
            enable_dns_support=True,
            enable_dns_hostnames=True,
            tags=[{"key": "Name", "value": "Vpcapp"}]
        )

        # 2. Create Internet Gateway
        igw = ec2.CfnInternetGateway(
            self, "InternetGateway",
            tags=[{"key": "Name", "value": "vpc-GW"}]
        )

        # Attach IGW to VPC
        ec2.CfnVPCGatewayAttachment(
            self, "VpcIgwAttachment",
            vpc_id=vpc.ref,
            internet_gateway_id=igw.ref
        )

        # Availability Zones to use (assumes 2 AZs in region)
        azs = [f"{self.region}a", f"{self.region}b"]

        # 3. Create Public Subnets (2)
        public_subnet_1 = ec2.CfnSubnet(
            self, "PublicSubnet1",
            vpc_id=vpc.ref,
            cidr_block="10.0.1.0/24",
            availability_zone=azs[0],
            map_public_ip_on_launch=True,
            tags=[{"key": "Name", "value": "PublicSubnet1"}]
        )
        public_subnet_2 = ec2.CfnSubnet(
            self, "PublicSubnet2",
            vpc_id=vpc.ref,
            cidr_block="10.0.2.0/24",
            availability_zone=azs[1],
            map_public_ip_on_launch=True,
            tags=[{"key": "Name", "value": "PublicSubnet2"}]
        )

        # 4. Create Private Subnets (2)
        private_subnet_1 = ec2.CfnSubnet(
            self, "PrivateSubnet1",
            vpc_id=vpc.ref,
            cidr_block="10.0.101.0/24",
            availability_zone=azs[0],
            map_public_ip_on_launch=False,
            tags=[{"key": "Name", "value": "PrivateSubnet1"}]
        )
        private_subnet_2 = ec2.CfnSubnet(
            self, "PrivateSubnet2",
            vpc_id=vpc.ref,
            cidr_block="10.0.102.0/24",
            availability_zone=azs[1],
            map_public_ip_on_launch=False,
            tags=[{"key": "Name", "value": "PrivateSubnet2"}]
        )

        # 5. Create Elastic IP for NAT Gateway
        eip = ec2.CfnEIP(
            self, "NatEIP",
            domain="vpc"
        )

        # 6. Create NAT Gateway in public subnet 1
        nat_gw = ec2.CfnNatGateway(
            self, "NatGateway",
            allocation_id=eip.attr_allocation_id,
            subnet_id=public_subnet_1.ref,
            tags=[{"key": "Name", "value": "vpc-NATGateway"}]
        )

        # 7. Create Route Table for Public Subnets
        public_rt = ec2.CfnRouteTable(
            self, "PublicRouteTable",
            vpc_id=vpc.ref,
            tags=[{"key": "Name", "value": "PublicRouteTable"}]
        )

        # 8. Create Route to Internet Gateway in Public Route Table
        ec2.CfnRoute(
            self, "PublicRoute",
            route_table_id=public_rt.ref,
            destination_cidr_block="0.0.0.0/0",
            gateway_id=igw.ref
        )

        # 9. Associate public subnets with public route table
        ec2.CfnSubnetRouteTableAssociation(
            self, "PublicSubnet1RouteTableAssoc",
            subnet_id=public_subnet_1.ref,
            route_table_id=public_rt.ref
        )
        ec2.CfnSubnetRouteTableAssociation(
            self, "PublicSubnet2RouteTableAssoc",
            subnet_id=public_subnet_2.ref,
            route_table_id=public_rt.ref
        )

        # 10. Create Route Table for Private Subnets
        private_rt = ec2.CfnRouteTable(
            self, "PrivateRouteTable",
            vpc_id=vpc.ref,
            tags=[{"key": "Name", "value": "PrivateRouteTable"}]
        )

        # 11. Create Route to NAT Gateway in Private Route Table
        ec2.CfnRoute(
            self, "PrivateRoute",
            route_table_id=private_rt.ref,
            destination_cidr_block="0.0.0.0/0",
            nat_gateway_id=nat_gw.ref
        )

        # 12. Associate private subnets with private route table
        ec2.CfnSubnetRouteTableAssociation(
            self, "PrivateSubnet1RouteTableAssoc",
            subnet_id=private_subnet_1.ref,
            route_table_id=private_rt.ref
        )
        ec2.CfnSubnetRouteTableAssociation(
            self, "PrivateSubnet2RouteTableAssoc",
            subnet_id=private_subnet_2.ref,
            route_table_id=private_rt.ref
        )

        # --- Outputs ---

        # VPC ID output
        CfnOutput(
            self, "VpcIdOutput",
            value=vpc.ref,
            export_name="VpcId"
        )

        # Public subnet outputs
        CfnOutput(
            self, "PublicSubnet1Id",
            value=public_subnet_1.ref,
            export_name="PublicSubnetId1"
        )
        CfnOutput(
            self, "PublicSubnet2Id",
            value=public_subnet_2.ref,
            export_name="PublicSubnetId2"
        )

        # Private subnet outputs
        CfnOutput(
            self, "PrivateSubnet1Id",
            value=private_subnet_1.ref,
            export_name="PrivateSubnetId1"
        )
        CfnOutput(
            self, "PrivateSubnet2Id",
            value=private_subnet_2.ref,
            export_name="PrivateSubnetId2"
        )

     # Save internal values for other stacks
        self.vpc_id = vpc.ref
        self.public_subnet_ids = [public_subnet_1.ref, public_subnet_2.ref]
        self.private_subnet_ids = [private_subnet_1.ref, private_subnet_2.ref]
#!/usr/bin/env python3
import aws_cdk as cdk

from webapp_infra.vpc import VpcStack
from webapp_infra.s3_bucket import S3Stack
from webapp_infra.alb import AlbStack
from webapp_infra.ecs import EcsStack
app = cdk.App()

vpc_stack = VpcStack(app, "VpcappStack")
s3_stack = S3Stack(app, "S3appStack")

alb_stack = AlbStack(
    app,
    "AlbappStack",
    vpc_id=vpc_stack.vpc_id,
    public_subnet_ids=vpc_stack.public_subnet_ids
)

ecs_stack = EcsStack(
    app,
    "EcsappStack",
    vpc_id=vpc_stack.vpc_id,
    private_subnet_ids=vpc_stack.private_subnet_ids,
    alb_sg_id=alb_stack.alb_sg,
    target_group_arn=alb_stack.tg_arn
)
# Ensure ALB is created after VPC
alb_stack.add_dependency(vpc_stack)
# Ensure ALB is created after VPC
ecs_stack.add_dependency(alb_stack)
app.synth()


# Web Application Infrastructure using AWS CDK (Python)

This project sets up a complete web application infrastructure on AWS using the AWS CDK (Cloud Development Kit) in Python. The infrastructure includes:

- A custom VPC with public and private subnets
- An S3 bucket for static assets
- An Application Load Balancer (ALB)
- An ECS Cluster with an EC2-based ECS Service

## 🧱 Stack Structure

The CDK application is composed of the following stacks:

| Stack         | Description                                                                 |
|---------------|-----------------------------------------------------------------------------|
| `VpcStack`    | Creates a VPC with public and private subnets                              |
| `S3Stack`     | Provisions an S3 bucket                                                    |
| `AlbStack`    | Sets up an Application Load Balancer (ALB) and target group               |
| `EcsStack`    | Launches an ECS cluster with an EC2 Auto Scaling Group and ECS service     |

## 🧰 Prerequisites

Ensure you have the following installed:

- [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html)
- [AWS CDK v2](https://docs.aws.amazon.com/cdk/v2/guide/work-with-cdk-python.html)
- Python 3.10+ and [pip](https://pip.pypa.io/en/stable/)
- A configured AWS CLI profile (i.e., `aws configure`)

---

## 🚀 Getting Started

### 1. Clone the Repository

```bash
git clone https://github.com/your-username/webapp-infra.git
cd webapp-infra
````


### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Bootstrap the CDK (if not done already)

```bash
cdk bootstrap
```

This step provisions the required resources (like S3 buckets for storing assets) that CDK needs to deploy your app.


## 📦 Synthesize the Stacks

Run the following command to deploy all stacks in order:

```bash
cdk synth --all
---

## 📦 Deploy the Stacks

Run the following command to deploy all stacks in order:

```bash
cdk deploy --all --require-approval never
```

> CDK will prompt you for approval before making changes to your AWS account. Type `y` to confirm.

### Optional: Deploy Stacks Individually

You may deploy each stack separately (respecting dependencies):

```bash
cdk deploy VpcappStack
cdk deploy S3appStack
cdk deploy AlbappStack
cdk deploy EcsappStack
```

---

## 🧼 Clean Up

To destroy all the provisioned resources:

```bash
cdk destroy --all
```

> ⚠️ This will delete **all resources** created by the CDK app, including the S3 bucket.

---


## 📚 References

* [AWS CDK Documentation](https://docs.aws.amazon.com/cdk/latest/guide/home.html)
* [ECS with EC2 launch type](https://docs.aws.amazon.com/AmazonECS/latest/userguide/launch_types.html)
* [CDK Constructs](https://constructs.dev/)

---


```
